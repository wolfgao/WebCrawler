var page = require('webpage').create();
page.open('http://www.ly.com/flight/flight-book1.aspx?para=0*PEK*CAN*2016-12-17****all*all&key=C50D785FEA6C93A88FF308D5FCACA8E0&TCAlianceCode=&filterlist=&fqdMark=2', function () {
    page.render('./example.png');
    phantom.exit();
});