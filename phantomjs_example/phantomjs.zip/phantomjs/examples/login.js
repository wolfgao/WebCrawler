var page = require('webpage').create();
page.viewportSize = { width: 1366, height: 600 };
var url='http://www.ly.com/FlightQuery.aspx'
page.open(url, function() {
    ret=page.evaluate(function() {
            ["txtAirplaneCity1"].value = '上海';
            form.elements["txtAirplaneCity2"].value = '北京';
			form.elements["txtAirplaneTime1"].value = '2016-12-19';
            form.elements['airplaneSubmit'].click();
 
            return document.title;
        });
    document.getElementsByTagName('button')[0].click();
    setTimeout('print_cookies()',10000)
});

function print_cookies(){
    console.info(JSON.stringify(page.cookies, undefined, 4))
    phantom.exit()
}
