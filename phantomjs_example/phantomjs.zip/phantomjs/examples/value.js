var page = require('webpage').create();
page.open('https://item.taobao.com/item.htm?spm=a21tz.8254990.7187356627.183.8soiwP&id=541719334887', function(status) {
  var domId = "J_SellCounter"
  var sellCounter = page.evaluate(function(id) {
    return document.getElementById(id).innerText;
  }, domId);

  console.log(sellCounter);
  phantom.exit();

});