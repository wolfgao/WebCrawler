var webPage = require('webpage');
var page = webPage.create();

page.viewportSize = { width: 1920, height: 1080 };
page.open("http://www.sina.com.cn", function start(status) {
  page.render('sina.jpeg', {format: 'jpeg', quality: '100'});
  phantom.exit();
});