var page = require('webpage').create(),
    url1 = "http://i.xue.taobao.com/detail.htm?courseId=32679",
    url2 = "https://item.taobao.com/item.htm?id=",
    itemId = 0,
    mItem = "",
    siteType = "taobao";
page.onConsoleMessage = function(msg) {
  console.log('console:  ' + msg);
};
page.onResourceReceived = function(response) {
    /*if(mItem = response.url.match(/^http\:\/\/(?:.*)[?|&]item=(\d*)/)) {
        itemId = mItem[1];
        console.log(itemId);
        phantom.exit();
    }*/
    // 获取课程对应的淘宝网商品id
    if(mItem = response.url.match(/itemId=(\d*)/)) {
        itemId = parseInt(mItem[1]);
    }
}
page.open(url1, function(status) {
    if(status !== "success") {
        console.log("tongxue fail!");
        phantom.exit();
    }
    page.render("tongxue.png")；
    // 打开课程对应的淘宝商品详情页。
    page.open(url2 + itemId, function(status) {
        if(status !== "success") {
            console.log("tongxue fail!");
            phantom.exit();
        }
        // 由于页面中的资源是动态加载的，需要setTimeout 10s 等待资源加载完，再操作页面。
        setTimeout(function() {
            var apply = page.evaluate(function() {
                // 获取课程交易量
                return document.getElementById("J_SellCounter").innerText;
                //return document.getElementById("bd");
            });
             console.log("apply:", apply);
            //fs.write("body.html", apply, "w");
            phantom.exit();
        }, 10000);

    });

});