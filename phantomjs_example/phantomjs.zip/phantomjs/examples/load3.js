var page = require('webpage').create(),url="http://blog.csdn.net";
page.open(url, function (status) {
 var title = page.evaluate(function () {
  return document.title;
 });
 console.log('Page title is ' + title);
});