var webPage = require("webpage");
var page = webPage.create();
var postBody = "user=username&password=password";

page.open("http://www.google.com/", "POST", postBody, function(status) {
  console.log("Status: " + status);
  // Do other things here...
   if(status !== "success") {
        phantom.exit();
    }
});