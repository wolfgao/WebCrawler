var page = require('webpage').create();
page.open('http://www.ly.com/FlightQuery.aspx', function () {
 page.render('example.png');
 phantom.exit();
});