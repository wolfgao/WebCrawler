var page = require("webpage").create();

page.open("http://ke.qq.com", function(status) {
    if(status !== "success") {
        console.log("open fail!");
    }
    phantom.exit();
});