var casper = require("casper").create(); 

casper.start('http://weibo.com/login') 

casper.wait(2000, function() {}); 

casper.waitForSelector(".W_login_form", function(){ 
this.fillSelectors('.W_login_form', { 
'input[name="username"]': 'weiweihappy321@sina.com.cn', 
'input[name="password"]': 's422835627S', 
}, false); 
this.click(".W_login_form .login_btn a"); 
}); 

casper.wait(5000, function(){ 
this.echo(this.getCurrentUrl()); 
this.capture("5000.jpg"); 
}); 

casper.run(); 
