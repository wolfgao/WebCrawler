var webPage = require("webpage"),
    page = webPage.create();