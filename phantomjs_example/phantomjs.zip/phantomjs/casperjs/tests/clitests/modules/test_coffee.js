var casper = require('casper').create();
var coffeemod = require('./sub/coffeemod');
console.log(coffeemod);
casper.exit();
