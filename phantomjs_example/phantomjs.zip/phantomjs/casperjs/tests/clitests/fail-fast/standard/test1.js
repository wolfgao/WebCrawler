casper.test.begin('test 1', 1, function(test) {
    test.assert(true);
    test.done();
});
